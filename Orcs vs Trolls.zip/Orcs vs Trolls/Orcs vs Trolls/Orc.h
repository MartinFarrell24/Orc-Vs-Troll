#pragma once
#include"Character.h"

class Orc : public Character
{
public:
	Orc();
	~Orc();
	void decrementHealth();
	int* healthPointer();
	bool getAlive();
	void setAlive();


private:
	int m_health;
	int m_strength;
	int *m_healthPointer;
	bool alive = true;
};