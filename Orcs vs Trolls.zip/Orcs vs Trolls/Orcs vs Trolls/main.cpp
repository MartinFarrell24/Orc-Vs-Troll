/// <summary>
/// @author Martin Farrell
/// @date 9th Oct 2017
/// </summary>

#ifdef _DEBUG 
#pragma comment(lib,"sfml-graphics-d.lib") 
#pragma comment(lib,"sfml-audio-d.lib") 
#pragma comment(lib,"sfml-system-d.lib") 
#pragma comment(lib,"sfml-window-d.lib") 
#pragma comment(lib,"sfml-network-d.lib") 
#else 
#pragma comment(lib,"sfml-graphics.lib") 
#pragma comment(lib,"sfml-audio.lib") 
#pragma comment(lib,"sfml-system.lib") 
#pragma comment(lib,"sfml-window.lib") 
#pragma comment(lib,"sfml-network.lib") 
#endif 

#include<iostream>
#include"Text.h"
#include"Orc.h"
#include"Troll.h"


/// <summary>
/// main entry point
/// </summary>
/// <returns>zero</returns>
int main()
{
	//declare variables
	Text game;//object of type text which contains all the game text
	Orc characterOne; //object of type Orc which is one faction a player can be
	Troll characterTwo; //object of type Troll which is one faction a player can be
	Character *player; //pointer to point to players chosen faction at run time
	Character *enemy; //pointer to point to enemy at run time
	bool faction = false; //bool used for faction choice


	//call functions
	game.choosefaction();//prompt player for faction choice
	int choice = game.getFaction(); //get choice from text.cpp
	if (choice == 1)//if choice = 1
	{
		//initialise pointers
		player = &characterOne; 
		enemy = &characterTwo;
		faction = false;
	}
	else //if choice = 2
	{
		//initialise pointers
		player = &characterTwo;
		enemy = &characterOne;
		faction = true;
	}
	game.gameIntro();//game explanation
	game.fightMechanics();//spells explained
	game.firstFight();//pre-emptive fight text

	while (characterOne.getAlive() == true && characterTwo.getAlive() == true)//while both the player and enemy are alive
	{
		game.fightSequence(); //prompts for input
		int type = game.getChoice(); //type of move (melee/spell/shield)
		int move = game.getSubChoice();// move num (melee 1-7 etc)
		if (type == 1)
		{
			if (move == 1)
			{
				enemy->decrementHealth(enemy->getStrength());//call appropriate function to decrement health
			}
			else if (move == 2)
			{
				enemy->meleeTwo();//call appropriate function to decrement health
			}
			else if (move == 3)
			{
				enemy->meleeThree();//call appropriate function to decrement health
			}
			else if (move == 4)
			{
				enemy->meleeFour();//call appropriate function to decrement health
			}
			else if (move == 5)
			{
				enemy->meleeFive();//call appropriate function to decrement health
			}
			else if (move == 6)
			{
				enemy->meleeSix();//call appropriate function to decrement health
			}
			else
			{
				enemy->meleeSeven();//call appropriate function to decrement health
			}
		}
		else if (type == 2)
		{
			if (move == 1)
			{
				enemy->spellOne();//call appropriate function to decrement health
			}
			else if (move == 2)
			{
				enemy->spellTwo();//call appropriate function to decrement health
			}
			else if (move == 3)
			{
				enemy->spellThree();//call appropriate function to decrement health
			}
			else if (move == 4)
			{
				enemy->spellFour();//call appropriate function to decrement health
			}
			else if (move == 5)
			{
				enemy->spellFive();//call appropriate function to decrement health
			}
		}
		else
		{
			if (move == 1)
			{
				enemy->shieldOne();//call shield function
			}
			else if (move == 2)
			{
				enemy->shieldTwo();//call shield function
			}
			else if (move == 3)
			{
				enemy->shieldThree();//call shield function
			}
		}
		if (player->getHealth() <= 0)
		{
			if (faction == true)
			{
				characterOne.setAlive();//set alive to false to break loop if player dies
			}
		}
		if (enemy->getHealth() <= 0)
		{
			if (faction == true)
			{
				characterTwo.setAlive(); //set alive to false to break loop if enemy dies
			}
		}
		game.resetChoices(); //re-initialise for next fight
	}

	game.fightCredit();// win/lose text
	std::system("pause");
	return 0;
}