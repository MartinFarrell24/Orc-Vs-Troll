#include"Orc.h"

Orc::Orc()
{
	m_strength = getStrength();
	m_health = getHealth();
	m_healthPointer = &m_health;
}

Orc::~Orc()
{
}

void Orc::decrementHealth()
{
}

int* Orc::healthPointer()
{
	return m_healthPointer;
}

bool Orc::getAlive()
{
	return alive;
}

void Orc::setAlive()
{
	alive = false;
}
