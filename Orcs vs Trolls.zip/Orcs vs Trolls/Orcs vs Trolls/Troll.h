#pragma once
#include"Character.h"

struct Troll : public Character
{
	Troll();
	~Troll();
	bool getAlive();//return bool for alive
	void setAlive();//set character to 

	int m_health;
	int m_strength;
	int *m_healthPointer;
	bool alive = true;
};
