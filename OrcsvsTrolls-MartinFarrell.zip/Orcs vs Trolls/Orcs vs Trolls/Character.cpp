#include"Character.h"

Character::Character()//constructor
{
}

Character::~Character()//destructor
{
}

int Character::getHealth()
{
	return health;
}

int Character::getStrength()
{
	return strength;
}

void Character::decrementHealth(float amount)
{
	if (buffed == true)
	{
		health -= (amount * 2.5);
	}
	else
	{
		health -= amount;
	}
}

void Character::meleeOne()//deals damage equal to strength
{
	decrementHealth(strength);
}

void Character::meleeTwo()//deals 1.5 times damage with 90% accuracy
{
	decrementHealth(strength * 1.5);
}

void Character::meleeThree()//kick does 0.75% damage with with chance to flinch
{
	decrementHealth(strength * 0.75);
}

void Character::meleeFour()//fake out, does 0.25% dmg with guaranteed flinch
{
	decrementHealth(strength * 0.25);
}

void Character::meleeFive()//dropkick, does 2x dmg can't move next turn
{
	decrementHealth(strength * 2);
}

void Character::meleeSix()//shank, does no initial damage but opponent bleeds for 10 each turn
{
	bleeding = true;
}

void Character::meleeSeven()//counter punch. fails if opponent doesn't attack but does 1.75% damage otherwise
{
	if (moving == true)
	{
		decrementHealth(strength * 1.75);
	}
}

void Character::spellOne()//reduces damage by 50%
{
	strength = strength * 0.5;
}

void Character::spellTwo()//paralyses opponent for a turn
{
	moving = false;
}

void Character::spellThree()//heals for 50%
{
	health = health + (health / 2);
}

void Character::spellFour()//next attack deals 2.5 x dmg
{
	buffed = true;
}

void Character::spellFive()//increases strength by 5 permanently
{
	strength += 5;
}

void Character::shieldOne()//heals by 25%
{
	health = health * 1.25;
}

void Character::shieldTwo()//reduces dmg taken by 50%
{
	shieldTwoActive = true;
}

void Character::shieldThree()//reduces dmg taken by 100%
{
	shieldThreeActive = true;
}
