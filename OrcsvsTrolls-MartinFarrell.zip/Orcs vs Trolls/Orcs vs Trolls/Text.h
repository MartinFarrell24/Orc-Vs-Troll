#pragma once
#include<iostream>

class Text
{
public:
	Text();
	~Text();
	void choosefaction();
	void gameIntro();
	void fightMechanics();
	int getFaction();
	void firstFight();
	void fightSequence();
	int getChoice();
	int getSubChoice();
	void fightCredit();
	void resetChoices();

private:
	int choice = 0;
	int subChoice = 0;
	int faction = 0;
	int *userHealth;
	int *enemyHealth;
	std::string player = "";
	std::string enemy = "";

};

