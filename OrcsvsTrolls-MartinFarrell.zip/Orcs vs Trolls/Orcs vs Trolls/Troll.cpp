#include"Troll.h"

Troll:: Troll()
{
	m_strength = getStrength();
	m_health = getHealth();
	m_healthPointer = &m_health;
}

Troll::~Troll()
{
}

bool Troll::getAlive()
{
	return alive;
}

void Troll::setAlive()
{
	alive = false;
}
