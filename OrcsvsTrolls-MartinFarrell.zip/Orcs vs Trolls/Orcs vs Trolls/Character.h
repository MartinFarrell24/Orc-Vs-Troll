#pragma once

class Character
{
public:
	Character();//constructor
	~Character();//destructor
	int getHealth();//returns health
	int getStrength();//returns strength
	virtual void decrementHealth(float amount);//universal overloaded decrement health function

	bool moving = true; //bool for character moving
	bool shieldTwoActive = false; //shield on or off
	bool shieldThreeActive = false; //shield on or off
	bool bleeding = false; //bleed damage on/off
	bool buffed = false; //spell boost on/off

	virtual void meleeOne();//deals damage equal to strength
	virtual void meleeTwo();//deals 1.5 times damage with 90% accuracy
	virtual void meleeThree();//kick does 0.75% damage with with chance to flinch
	virtual void meleeFour();//fake out, does 0.25% dmg with guaranteed flinch
	virtual void meleeFive();//dropkick, does 2x dmg can't move next turn
	virtual void meleeSix();//shank, does no initial damage but opponent bleeds for 10 each turn
	virtual void meleeSeven();//counter punch. fails if opponent doesn't attack but does 1.75% damage otherwise

	virtual void spellOne();//reduces damage by 50%
	virtual void spellTwo();//paralyses opponent for a turn
	virtual void spellThree();//heals for 50%
	virtual void spellFour();//next attack deals 2.5 x dmg
	virtual void spellFive();//increases strength by 5 permanently

	virtual void shieldOne();//heals by 25%
	virtual void shieldTwo();//reduces dmg taken by 50%
	virtual void shieldThree();//reduces dmg taken by 100%

private:
	int health = 100; //base health
	int strength = 11; //base strength
};

