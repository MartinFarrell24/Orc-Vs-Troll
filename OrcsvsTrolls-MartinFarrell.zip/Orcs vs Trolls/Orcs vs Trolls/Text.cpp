#include"Text.h"
#include<cstdlib>
#include<string>

Text::Text()
{
}

Text::~Text()
{
}

void Text::choosefaction()
{
	std::cout << "Welcome to Orcs vs Trolls. Please choose your faction: " << std::endl;
	std::system("pause");
	std::system("CLS");
	std::cout << "Enter 1 for Orcs or 2 for Trolls" << std::endl;
	std::cin >> faction;

	while (faction < 1 || faction > 2)
	{
		std::cout << "That's not an option. Please enter 1 for Orcs or 2 for Trolls." << std::endl;
		std::cin >> faction;
	}
	std::system("CLS");
	if (faction == 1)
	{
		std::cout << "You have chosen : Orc" << std::endl;
	}
	else
	{
		std::cout << "You have chosen : Troll" << std::endl;
	}
	std::system("pause");
	std::system("CLS");
}

void Text::gameIntro()
{
	if (faction == 1)
	{
		player = "Orc";
		enemy = "Troll";
	}
	else
	{
		player = "Troll";
		enemy = "Orc";
	}
	std::cout << "Welcome initiate. An army of " << enemy << " has been spotted" << std::endl << "heading in this direction. They wish to dethrone our " << player << " King."
		<< std::endl << "Brothers, please prepare yourselves for battle." << std::endl << "One of your superiors will teach you how to fight";
	std::system("pause");
	std::system("CLS");
}

void Text::fightMechanics()
{
	std::cout << "Listen up recruit coz I aint gonna tell you more than once. In combat us " << player << "can deal damage in two ways. " << std::endl <<
		"With magic or melee attacks. Each spell can only be used once per battle but you can use melee attacks indefinitely." << std::endl << "The magic spells: " << std::endl << "(1)reduces damage of next attack by 50%"
		<< std::endl << "(2)Paralyses your opponent momentarily" << std::endl << "(3)Heals you by 50%" << std::endl << "(4)boosts your next attack by 250%" << std::endl << "(5)Increases your strength";
	std::system("pause");
	std::system("CLS");
}

int Text::getFaction()
{
	return faction;
}

void Text::firstFight()
{
	std::cout << "The first wave are just basic " << enemy << "grunts, they can't use magic." << std::endl <<
		"Get into formation with your shield-brothers and prepare for battle." << std::endl << std::endl;
	std::cout << "Your first opponent has arrived, enter the number refering to the attack you wish to do." << std::endl;
	std::system("pause");
	std::system("CLS");
}

void Text::fightSequence()
{
	//variables for choices
	

	while (choice < 1 || choice > 3)
	{
		std::cout << "How would you like to attack?(1)melee (2)Magic (3)Shield.(enter corresponding num)" << std::endl;
		std::cin >> choice;
		std::system("CLS");

	}
	if (choice == 1)
	{
		while (subChoice < 1 || subChoice > 7)
		{
			std::cout << "Which melee attack would you like to use?(enter a num 1-7)" << std::endl;
			std::cin >> subChoice;
		}
	}
	else if (choice == 2)
	{
		while (subChoice < 1 || subChoice > 5)
		{
			std::cout << "Which spell would you like to use?(enter a num 1-5)" << std::endl;
			std::cin >> subChoice;
		}
	}
	else if (choice == 3) 
	{
		std::cout << "Which shield would you like to use?(enter a num 1-3)" << std::endl;
		std::cin >> subChoice;
	}
}

int Text::getChoice()
{
	return choice;
}

int Text::getSubChoice()
{
	return subChoice;
}

void Text::fightCredit()
{
	std::cout << "Well done fledgling you have defeated your first enemy but there's no time to relax now." << std::endl <<
		"More of them will come, prepare yourself" << std::endl;
	std::system("pause");
}

void Text::resetChoices()
{
	choice = 0;
	subChoice = 0;
}
